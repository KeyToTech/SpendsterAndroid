package com.spendster.presentation.addExpenses.chooseCategory;

import com.spendster.data.entity.Category;

public interface OnCategoryClickListener {
    void onCategoryClick(Category item);
}
