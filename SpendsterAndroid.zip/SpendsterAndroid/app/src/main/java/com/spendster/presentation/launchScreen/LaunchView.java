package com.spendster.presentation.launchScreen;

public interface LaunchView {
    void startHomeScreen();
    void startWelcomeScreen();
}
