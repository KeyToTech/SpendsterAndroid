package com.spendster.presentation.validation;

public interface Validation<T> {
    T validate();
}
