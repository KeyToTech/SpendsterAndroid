package com.spendster.presentation;

public interface ErrorsView {
    void showError(String message);
    void hideError();
}
