package com.spendster.presentation.homeScreen;

public interface HomeView {
    void addExpenses();
    void goToWelcomeScreen();
}
