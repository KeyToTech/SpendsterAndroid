package com.spendster.presentation.utils;

public interface SDateFormats {
    String TIME_FORMAT = "EE, dd MMM HH:mm";
}
