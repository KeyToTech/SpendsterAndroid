package com.spendster.presentation;

public interface LoadingView {
    void showLoading();
    void hideLoading();
}

