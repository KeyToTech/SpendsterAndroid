package com.spendster.presentation.address;

public interface AddressView {
    void showError(String message);

    void showNextScreen();
}
