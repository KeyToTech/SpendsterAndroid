package com.spendster.presentation.addExpenses;

import com.spendster.presentation.ErrorsView;

public interface AddExpensesView extends ErrorsView {
    void successFinish();
}
