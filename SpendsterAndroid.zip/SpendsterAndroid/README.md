# SpendsterAndroid

[![CircleCI](https://circleci.com/gh/KeyToTech/SpendsterAndroid.svg?style=svg)](https://circleci.com/gh/KeyToTech/SpendsterAndroid)
